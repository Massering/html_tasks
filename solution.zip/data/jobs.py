import datetime
import sqlalchemy
from sqlalchemy import Column as Col
from .db_session import SqlAlchemyBase


class Jobs(SqlAlchemyBase):
    __tablename__ = 'jobs'

    id = Col(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    team_leader = Col(sqlalchemy.Integer, sqlalchemy.ForeignKey("users.id"))
    job = Col(sqlalchemy.String)
    work_size = Col(sqlalchemy.Integer)
    collaborators = Col(sqlalchemy.String)
    start_date = Col(sqlalchemy.DateTime, default=datetime.datetime.now)
    end_date = Col(sqlalchemy.DateTime, default=datetime.datetime.now)
    is_finished = Col(sqlalchemy.Boolean)
