from flask import Flask, render_template, url_for, request, make_response, redirect
import requests
from datetime import datetime

from data import db_session
from data.users import User
from data.jobs import Jobs

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


if __name__ == '__main__':
    db_session.global_init("db/blogs.db")

    job_params = {
        "team_leader": 1,
        "job": "deployment of residential modules 1 and 2",
        "work_size": 15,
        "collaborators": "2, 3",
        "start_date": datetime.now(),
        "is_finished": False,
    }

    job = Jobs(**job_params)
    session = db_session.create_session()
    session.add(job)
    session.commit()

    app.run()
